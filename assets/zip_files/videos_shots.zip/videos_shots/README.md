Dieses Archiv wurde für die Verwendung innerhalb der OER [*Workflows zur automatisierten Filmannotation – Einstellungs- und Figurenerkennung am Beispiel der Filme Konrad Wolfs*](https://quadriga-dk.github.io/Bewegtes-Bild-Fallstudie-4/) erstellt. Die OER entstand als Teil des [*Quadriga Berlin-Brandenburgischen Datenkompetenzzentrums*](https://www.quadriga-dk.de/de).

Konkret enthält dieses Archiv die Testdateien für die Ausführung des Jupyter Notebooks zur [*Automatischen Erkennung von Einstellungen mit TransNetV2*](https://quadriga-dk.github.io/Bewegtes-Bild-Fallstudie-4/annotation/einstellungen_notebook.html).
Neben diesem README.md liegen die folgenden Dateien bei:

- `Der geteilte Himmel_Trailer_1964.mp4`
    - Trailerdatei zur Auswertung im Jupyter Notebook
- `DEFA_Nutzungshinweis.md`
    - Nutzungshinweis zur Trailerdatei


