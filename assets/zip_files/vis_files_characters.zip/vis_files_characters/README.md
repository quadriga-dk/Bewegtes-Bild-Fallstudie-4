Dieses Archiv wurde für die Verwendung innerhalb der OER [*Workflows zur automatisierten Filmannotation – Einstellungs- und Figurenerkennung am Beispiel der Filme Konrad Wolfs*](https://quadriga-dk.github.io/Bewegtes-Bild-Fallstudie-4/) erstellt. Die OER entstand als Teil des [*Quadriga Berlin-Brandenburgischen Datenkompetenzzentrums*](https://www.quadriga-dk.de/de).

Konkret enthält dieses Archiv die Testdateien zur Ausführung des Jupyter Notebooks [*Visualisierung der Ergebnisse der Figurenerkennung*](https://quadriga-dk.github.io/Bewegtes-Bild-Fallstudie-4/auswertung/visualisierung_figuren.html).
Neben diesem README.md liegen die folgenden Dateien bei:

- Drei Unterordner mit den Ergebnissen des Jupyter Notebooks [*Automatische Erkennung von Figuren mit InsightFace*](https://quadriga-dk.github.io/Bewegtes-Bild-Fallstudie-4/annotation/figuren_notebook.html). 
    - Ausgewertet wurden drei Filme Konrad Wolfs:
        - `Der geteilte Himmel_1964`
        - `Solo Sunny_1980`
        - `Sonnensucher_1958`
    - Jeder Ordner enthält vier Dateien:
        - `Filmtitel_Veröffentlichungsjahr_characters_annotations.csv`
            - Die Datei fasst aufeinanderfolgende Erkennungen einer Figur zu längeren Zeitintervallen zusammen.
        - `Filmtitel_Veröffentlichungsjahr_characters_annotations.eaf`
            - Anhand dieser Datei lassen sich die Figurenerkennung und die Einstellungserkennung gemeinsam in VIAN oder andere Annotationsprogramme importieren, überprüfen und weiterbearbeiten.
        - `Filmtitel_Veröffentlichungsjahr_characters_frames.csv`
            - Die Datei dokumentiert die Erkennung einzelner Figuren in den analysierten Videoframes.
        - `Filmtitel_Veröffentlichungsjahr_characters_metadata.csv`
            - Die Datei enthält technische Metadaten, Analyseparameter und statistische Kennwerte der erkannten Figuren.
    - Weitere Informationen zu diesen Dateien gibt es im OER-Abschnitt zur [Ausgabe des Notebooks zur Figurenerkennung](https://quadriga-dk.github.io/Bewegtes-Bild-Fallstudie-4/annotation/figuren_intro.html#ausgabe).



