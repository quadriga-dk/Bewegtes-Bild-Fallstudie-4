Dieses Archiv wurde für die Verwendung innerhalb der OER [*Workflows zur automatisierten Filmannotation – Einstellungs- und Figurenerkennung am Beispiel der Filme Konrad Wolfs*](https://quadriga-dk.github.io/Bewegtes-Bild-Fallstudie-4/) erstellt. Die OER entstand als Teil des [*Quadriga Berlin-Brandenburgischen Datenkompetenzzentrums*](https://www.quadriga-dk.de/de).

Konkret enthält dieses Archiv die Testdateien zur Ausführung des Jupyter Notebooks [*Visualisierung der Ergebnisse der Einstellungserkennung*](https://quadriga-dk.github.io/Bewegtes-Bild-Fallstudie-4/auswertung/visualisierung_einstellungen.html).
Neben diesem README.md liegen die folgenden Dateien bei:

- Unterordner `Metadaten`
    - 14 `.csv`-Dateien im Format `Filmtitel_Veröffentlichungsjahr_shots_0.5_metadata.csv`
        - Die Dateien enthalten Kennwerte zu den Ergebnissen des Jupyter Notebooks [*Automatische Erkennung von Einstellungen mit TransNetV2*](https://quadriga-dk.github.io/Bewegtes-Bild-Fallstudie-4/annotation/einstellungen_notebook.html)
        - Ausgewertet wurden die 14 Spielfilme Konrad Wolfs.
    - Weitere Informationen zu diesen Dateien gibt es im OER-Abschnitt zur [Ausgabe des Notebooks zur Einstellungserkennung](https://quadriga-dk.github.io/Bewegtes-Bild-Fallstudie-4/annotation/einstellung_intro.html#ausgabe).



